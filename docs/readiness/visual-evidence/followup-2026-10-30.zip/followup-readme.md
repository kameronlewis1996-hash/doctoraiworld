# DoctorAI visual review screenshots

These local Chromium screenshots use fictional or empty data and fallback fonts. They are not physical-phone or production captures.

- [Documents before](documents-before-320.png) and [after](documents-after-320.png): the filter row wraps instead of clipping labels.
- [Sign-in error before](auth-error-before-320.png) and [after](auth-error-after-320.png): the error panel uses the Hub blue surface.

The full route matrix and remaining review limits are in the PR's visual audit report.
