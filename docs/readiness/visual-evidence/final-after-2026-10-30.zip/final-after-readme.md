# DoctorAI final visual captures

These screenshots use local Chromium with fictional or empty data and fallback fonts. They are not production or physical-device captures.

- [Documents Pro link](documents-pro-link-after-320.png): label and arrow remain on one line at 320px.
- [Home footer](footer-home-after-390.png): the genuine DoctorAI mark uses the same 42px footer treatment as the public-page footer.
