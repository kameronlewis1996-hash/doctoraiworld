# DoctorAI premium refinement: medication and dialog

Local Chromium captures at 390px using fallback fonts and a fictional long medicine label. The dialog content and clinical warnings were preserved. These are not production or physical-phone images.
